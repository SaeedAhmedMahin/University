# nmckt
Chat application made with C and Ncurses (Socket programming) 

## Requirements Summary 
1. Private messaging
2. Global Messages to all users
3. Message history is saved
4. Ncurses for TUI (users should have different colors in global chat)
5. Notifications when users join or leave.
6. Color customization per user or group

# How to use:
1. Open atleast 2 terminals one for server and one or more for client(s).
2. On the server terminal type " gcc server.c net_helper.c -lpthread -o server" and then type ./server 9000 to run the server 
3. On the client terminal type " gcc client.c net_helper.c -lpthread -lncurses -lmenu -o client" and then type ./client 127.0.0.1 9000 to run the client
4. In the client terminal Login first, check users.txt for name and passwords of predefined users. After logging in you can chat in the global chat. Write /username to DM that user and /global to switch to global chat. You can see the active users on the left side of the screen.
5. More functionalities will be added in the future, currently there exists no user registration.
6. There may be some bugs here and there, please let me know if you find any! Thanks!


