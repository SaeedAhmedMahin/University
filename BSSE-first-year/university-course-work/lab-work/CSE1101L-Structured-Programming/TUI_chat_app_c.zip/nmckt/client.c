#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <ncurses.h>
#include <menu.h>
#include <unistd.h>
#include "net_helper.h"

#define BUF 512
#define MAX_MESSAGES 512
#define MAX_USERS 128
#define MAX_MSG_LEN 512
#define MAX_NAME_LEN 64

// -------- Globals --------
char username[BUF];
int global_chat = 1;
char current_target[MAX_NAME_LEN] = "glo/bal";
char path_global[100] = "./DB/global.txt";
char path_dm[100];
Connection *srv = NULL;

// Chat + user state
char *chat_history_messages[MAX_MESSAGES];
int chat_message_count = 0;
char *active_users[MAX_USERS];
int active_user_count = 0;

// UI windows
ITEM **my_items = NULL;
int n_choices = 0;
MENU *my_menu = NULL;
WINDOW *win_users = NULL, *win_chat = NULL, *win_input = NULL;

pthread_mutex_t db_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t conn_mutex = PTHREAD_MUTEX_INITIALIZER;

// -------- UTILITIES --------
static WINDOW *create_newwin(int h, int w, int y, int x) {
    WINDOW *win = newwin(h, w, y, x);
    box(win, 0, 0);
    wrefresh(win);
    return win;
}

void safe_free_str_array(char **arr, int count) {
    if (!arr) return;
    for (int i = 0; i < count; ++i)
        free(arr[i]);
}


// -------- FILE DB --------
void write_to_DB(const char *path, const char *line) {
    pthread_mutex_lock(&db_mutex);
    FILE *fp = fopen(path, "a");
    if (!fp) {
        perror("DB open failed");
        pthread_mutex_unlock(&db_mutex);
        return;
    }
    fprintf(fp, "%s\n", line);
    fclose(fp);
    pthread_mutex_unlock(&db_mutex);
}

void load_history(const char *path) {
    safe_free_str_array(chat_history_messages, chat_message_count);
    chat_message_count = 0;
    FILE *fp = fopen(path, "r");
    if (!fp) return;
    char line[BUF];
    while (fgets(line, sizeof(line), fp) && chat_message_count < MAX_MESSAGES) {
        line[strcspn(line, "\n")] = '\0';
        chat_history_messages[chat_message_count++] = strdup(line);
    }
    fclose(fp);
}

void load_active_users(const char *path_active) {
    safe_free_str_array(active_users, active_user_count);
    active_user_count = 0;
    FILE *fp = fopen(path_active, "r");
    if (!fp) return;
    char buf[128];
    while (fgets(buf, sizeof(buf), fp) && active_user_count < MAX_USERS) {
        buf[strcspn(buf, "\n")] = '\0';
        active_users[active_user_count++] = strdup(buf);
    }
    fclose(fp);
}

// -------- UI DRAW --------
void draw_chat_window() {
    if (!win_chat) return;
    werase(win_chat);
    box(win_chat, 0, 0);
    int y = 1, maxy, maxx;
    getmaxyx(win_chat, maxy, maxx);
    int start = (chat_message_count > maxy - 2) ? chat_message_count - (maxy - 2) : 0;
    for (int i = start; i < chat_message_count; ++i)
        mvwprintw(win_chat, y++, 1, "%.*s", maxx - 2, chat_history_messages[i]);
    wrefresh(win_chat);
}

void rebuild_user_menu_items() {
    if (my_menu) {
        unpost_menu(my_menu);
        free_menu(my_menu);
    }
    if (my_items) {
        for (int i = 0; i < n_choices; ++i) free_item(my_items[i]);
        free(my_items);
    }

    n_choices = active_user_count;
    my_items = (ITEM **)calloc(n_choices + 1, sizeof(ITEM *));
    for (int i = 0; i < n_choices; ++i)
        my_items[i] = new_item(active_users[i], "-Online");
    my_items[n_choices] = NULL;

    my_menu = new_menu(my_items);
    set_menu_win(my_menu, win_users);
    set_menu_sub(my_menu, derwin(win_users, getmaxy(win_users)-2, getmaxx(win_users)-2, 1, 1));
    post_menu(my_menu);
    wrefresh(win_users);
}

// -------- UI THREAD --------
void *ui_thread_fn(void *arg) {
    initscr(); cbreak(); noecho(); keypad(stdscr, TRUE); curs_set(1);
    int user_w = COLS / 6;
    int chat_w = COLS - user_w - 3;
    int chat_h = (int)(LINES * 0.75);
    int input_h = 3;
    win_users = create_newwin(chat_h, user_w, 1, 1);
    win_chat  = create_newwin(chat_h, chat_w, 1, user_w + 2);
    win_input = create_newwin(input_h, chat_w + user_w + 1, chat_h + 2, 1);
    scrollok(win_chat, TRUE);

    mvprintw(LINES - 1, 0, "Enter: send | /global or /<username> to DM | F1 quit | F4 reload");
    refresh();

    draw_chat_window();
    rebuild_user_menu_items();

    int ch, j = 0;
    char buf[MAX_MSG_LEN] = {0};
    mvwprintw(win_input, 1, 2, "> ");
    wmove(win_input, 1, 4);
    wrefresh(win_input);

    while ((ch = wgetch(win_input)) != KEY_F(1)) {
        if (ch == KEY_F(4)) {
            load_history(global_chat ? path_global : path_dm);
            draw_chat_window();
            continue;
        }

        if (ch > 31 && ch < 128) {
            if (j < MAX_MSG_LEN - 1) {
                buf[j++] = (char)ch;
                waddch(win_input, ch);
                wrefresh(win_input);
            }
        } else if (ch == '\n') {
            buf[j] = '\0';
            if (j > 0) {
                // handle mode switch
                if (strncmp(buf, "/global", 7) == 0) {
                    global_chat = 1;
                    strcpy(current_target, "global");
                    load_history(path_global);
                    draw_chat_window();
                } else if (buf[0] == '/' && strlen(buf) > 1) {
                    snprintf(current_target, sizeof(current_target), "%s", buf + 1);
                    // Create consistent DM filename (alphabetically sorted)
		char user1[MAX_NAME_LEN], user2[MAX_NAME_LEN];
		strncpy(user1, username, MAX_NAME_LEN);
		strncpy(user2, current_target, MAX_NAME_LEN);
		user1[MAX_NAME_LEN - 1] = '\0';
		user2[MAX_NAME_LEN - 1] = '\0';

		if (strcasecmp(user1, user2) > 0) {
		    snprintf(path_dm, sizeof(path_dm), "./DB/%s_%s.txt", user2, user1);
		} else {
		    snprintf(path_dm, sizeof(path_dm), "./DB/%s_%s.txt", user1, user2);
}

                    global_chat = 0;
                    load_history(path_dm);
                    draw_chat_window();
                } else {
                    char formatted[BUF];
                    snprintf(formatted, sizeof(formatted),
                             "%s: %s",
                             username,
                             
                             buf);

                    // Local write only once
                    const char *target_path = global_chat ? path_global : path_dm;
                    write_to_DB(target_path, formatted);
                    load_history(target_path);
                    draw_chat_window();

                    // Send to server
                    pthread_mutex_lock(&conn_mutex);
                    conn_write(srv, formatted, (unsigned int)strlen(formatted));
                    pthread_mutex_unlock(&conn_mutex);
                }
            }

            // reset input
            werase(win_input);
            box(win_input, 0, 0);
            mvwprintw(win_input, 1, 2, "> ");
            wmove(win_input, 1, 4);
            wrefresh(win_input);
            memset(buf, 0, sizeof(buf));
            j = 0;
        } else if (ch == KEY_BACKSPACE || ch == 127) {
            if (j > 0) {
                j--;
                int y, x;
                getyx(win_input, y, x);
                if (x > 3) {
                    mvwdelch(win_input, y, x - 1);
                    wrefresh(win_input);
                }
            }
        }
    }

    endwin();
    return NULL;
}

// -------- MAIN --------
int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <server_ip> <port>\n", argv[0]);
        return 1;
    }
    const char *server_ip = argv[1];
    unsigned int port = atoi(argv[2]);

    srv = client_connect(server_ip, port);
    if (!srv) {
        perror("client_connect");
        return 1;
    }
    
    FILE *fp_active_users = fopen("./DB/active_users.txt", "w");
    fclose(fp_active_users);

    printf("Connected to server %s:%u\n", server_ip, port);
    

    // login
    char buf[BUF];
    int logged_in = 0;
    while (!logged_in) {
        char password[BUF];
        printf("Username: ");
        fgets(username, BUF, stdin);
        username[strcspn(username, "\n")] = '\0';
        printf("Password: ");
        fgets(password, BUF, stdin);
        password[strcspn(password, "\n")] = '\0';
        snprintf(buf, BUF, "LOGIN:%s|%s", username, password);
        pthread_mutex_lock(&conn_mutex);
        conn_write(srv, buf, (unsigned int)strlen(buf));
        ssize_t n = conn_read(srv, buf, BUF - 1);
        pthread_mutex_unlock(&conn_mutex);
        if (n > 0) {
            buf[n] = '\0';
            if (strcmp(buf, "OK") == 0) {
            	FILE *fp_active_users = fopen("./DB/active_users.txt", "a");
		if (fp_active_users == NULL) {
		    perror("fopen");
		    /* handle error */
		} else {
           		logged_in = 1;
            	}
            }
            else printf("Login failed: %s\n", buf);
        }
    }

    load_history(path_global);
    load_active_users("./DB/active_users.txt");
  

    pthread_t ui_thread;
    
    pthread_create(&ui_thread, NULL, ui_thread_fn, NULL);

    while (1) {
        ssize_t n = conn_read(srv, buf, BUF - 1);
        if (n > 0) {
            buf[n] = '\0';
            // Avoid echoing own message
            if (strncmp(buf, username, strlen(username)) != 0) {
                write_to_DB(path_global, buf);
                load_history(global_chat ? path_global : path_dm);
                load_active_users("./DB/active_users.txt");
            }
        } else if (n == 0) break;
        usleep(100000);
    }

    pthread_cancel(ui_thread);
    pthread_join(ui_thread, NULL);
    conn_close(srv);
    printf("Disconnected.\n");
    return 0;
}

